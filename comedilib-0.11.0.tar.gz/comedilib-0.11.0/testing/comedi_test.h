
#ifndef _COMEDI_TEST_H_
#define _COMEDI_TEST_H_

extern char *filename;
extern comedi_t *device;

extern int subdevice;

extern int verbose;

extern unsigned int capabilities;

extern int realtime;

#endif

