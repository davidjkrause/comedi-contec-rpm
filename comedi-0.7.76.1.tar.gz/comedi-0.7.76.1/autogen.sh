#!/bin/bash
autoreconf -i -B m4

