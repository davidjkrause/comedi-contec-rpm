#define CONFIG_APCI_1564 1

#define ADDIDATA_DRIVER_NAME "addi_apci_1564"

#include "addi-data/addi_common.c"
