#define CONFIG_APCI_2016 1

#define ADDIDATA_DRIVER_NAME "addi_apci_2016"

#include "addi-data/addi_common.c"
