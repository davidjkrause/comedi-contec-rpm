#define CONFIG_APCI_3501 1

#define ADDIDATA_DRIVER_NAME "addi_apci_3501"

#include "addi-data/addi_common.c"
