#define CONFIG_APCI_3XXX 1

#define ADDIDATA_DRIVER_NAME "addi_apci_3xxx"

#include "addi-data/addi_common.c"
