#define CONFIG_APCI_16XX 1

#define ADDIDATA_DRIVER_NAME "addi_apci_16xx"

#include "addi-data/addi_common.c"
