#define CONFIG_APCI_2032 1

#define ADDIDATA_DRIVER_NAME "addi_apci_2032"

#include "addi-data/addi_common.c"
