#define CONFIG_APCI_035 1

#define ADDIDATA_WATCHDOG 2	// Or shold it be something else

#define ADDIDATA_DRIVER_NAME "addi_apci_035"

#include "addi-data/addi_common.c"
