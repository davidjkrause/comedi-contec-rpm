#define CONFIG_APCI_1516 1

#define ADDIDATA_DRIVER_NAME "addi_apci_1516"

#include "addi-data/addi_common.c"
