#define CONFIG_APCI_1032 1

#define ADDIDATA_DRIVER_NAME "addi_apci_1032"

#include "addi-data/addi_common.c"
