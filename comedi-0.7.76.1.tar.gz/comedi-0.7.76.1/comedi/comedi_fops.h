
#ifndef _COMEDI_FOPS_H
#define _COMEDI_FOPS_H

extern struct class *comedi_class;
extern const struct file_operations comedi_fops;
extern COMEDI_MODULE_PARAM_BOOL_T comedi_autoconfig;

#endif //_COMEDI_FOPS_H
